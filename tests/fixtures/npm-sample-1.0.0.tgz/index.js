module.exports = {
  tokenA: "alpha-token",
  tokenB: "beta-token",
};
